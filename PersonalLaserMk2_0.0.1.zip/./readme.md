PersonalLaserMk2/
├── data.lua
├── info.json
├── graphics/
│   ├── icons/
│   │   └── personal-laser-defense-mk2.png
│   ├── entity/
│   │   └── personal-laser-defense-mk2.png
├── prototypes/
│   ├── item.lua
│   ├── recipe.lua
│   ├── technology.lua
│   ├── projectile.lua